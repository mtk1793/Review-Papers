# Cross-manuscript alignment and earlier-repository audit — 10 November 2026

## Scope

Compared this archive's manuscript index and source/provenance notes against the current public `mtk1793/Review-Papers` repository (13 older CAPSM/standards/PG-CARE paper families, plus related code and source artifacts). This is a document-level and source-availability audit, **not** a new scientific replication. Prior files are preserved without overwriting.

## Non-equivalence rules

1. **Identifiers:** new P01–P16 are an independent archive. Old Paper 1 = PRC-029 ride-through, not new P01 = Canadian PRC review. Old Paper 3 = MOD-026 surrogate, while new P03 is generic CNN-LSTM validation. Do not renumber or merge manuscripts by numerical ID alone.
2. **MOD model validation:** old `papers/CNNLSTM_ModelValidation_MOD026_AcademicPaper_2026-09-08.docx` is materially more developed than new P02 concept. Preserve both. MOD-026-2 excitation/governor-related scope cannot be conflated with MOD-033-1 plant dynamic performance; applicability and approval dates must be validated against official requirements.
3. **CNN-LSTM:** generic V-CNNLSTM-RC methodology (new P03) differs from parameter-estimation surrogate (old Paper 3), and from System-1 CNN-LSTM fast fault detector (old Paper 12). Results across these tasks are not directly comparable.
4. **EV:** new P10 documents supervisory Simulink controller lineage; new P04 predicts one-hour-ahead EV states; old Paper 13 PG-CARE v2 adds leak-free, uncertainty-aware flexibility forecasting plus IEEE 33-bus QSTS. They are distinct study stages. Old Paper 13 self-identifies measured-data external validation as pending.
5. **THD:** new P06/P07 share an electrical harmonic forecasting theme; evaluate with the same chronological split, independent held-out test and leakage-safe selection. Their physical claims are different.
6. **FACTS:** P05 SVC firing-angle estimation is an algorithmic prediction task; P13 generalized FACTS framework, old Paper 6 hosting-capacity and PSS/E controller stability are distinct physical/engineering validation tasks.
7. **Reviews:** P01 (PRC legal/technical), P11 (smart-grid technologies), P12 (AI data-center power), P15 (storage choices for transmission planning) should use non-overlapping research questions and explicit selection windows. Review content reused across them must be cited and not submitted as redundant publication.
8. **Hydrogen:** P14 dynamic offshore-wind–hydrogen–BESS agents, P15 comparative storage and P16 solar–hydrogen–EV charging are separate; P14/P15 original evidence was unavailable to the November archive, P16 is a concept.

## Submission-blocking evidence issues

- Source-reported numerical model metrics have not been reproduced in the revision archive. No PSSE/PSCAD/MATLAB/PyTorch experiment was executed for these rewrites.
- New P02/P14/P15 are proposed methods/review frameworks, not completed experiments.
- P12's underlying preserved narrative refers to **185** sources, while another source revision reported **178**; no reconciled PRISMA search/screening ledger is in this archive. Do not quote a verified systematic count until resolved.
- New P04 paper title historically conflates discrete EV operating-state classification with continuous battery SoC prediction. State exact target, horizon, units and metrics.
- P03 source numerical performance, interval coverage and regression 'ECE' interpretation must be checked against code and prediction records. Classification calibration and regression interval coverage are not interchangeable.
- P01 current NERC PRC versions, Canadian provincial enforceability, Quebec framework, and regulator chronology require an official dated verification.
- Per-paper `references_to_verify.bib` contains DOI anchors, **not verified complete Zotero-ready bibliography entries**. Preserve citation provenance and repair metadata.
- Existing PG-CARE v2 explicitly lacks executed external measured-data validation; do not borrow its reported synthetic metrics to substantiate P04 or P10.

## Source lineage overview

| New project | Closest earlier repository source | Relationship |
|---|---|---|
| P01 | Old Paper 1 PRC-029 | Shared standards family; different review vs simulation |
| P02 | `papers/CNNLSTM_ModelValidation_MOD026_AcademicPaper_2026-09-08.docx`; `scripts/paper3_cnnlstm_model_validation.py` | Earlier complete related manuscript and executable surrogate; do not replace |
| P03 | `papers/V-CNNLSTM-RC_ValidationFramework_AcademicPaper_2026-09-09.docx` | Earlier version of source document |
| P04 | `papers/paper13_pgcare_ev_flexibility/` | Related EV forecasting lineage; distinct targets and evidence |
| P05 | Old Paper 6 FACTS hosting-capacity | Different SVC prediction objective |
| P06/P07 | No exact earlier repository match | Companion THD problems |
| P08/P09 | No exact earlier repository match | Distinct solar/wind datasets |
| P10 | `papers/paper13_pgcare_ev_flexibility/source_artifacts/` | Published physical-controller source reused as historical input to PG-CARE |
| P11/P12 | No exact earlier repository match | Broad technology reviews |
| P13 | Old Paper 6 FACTS | Related topic, different scope |
| P14/P15/P16 | No exact earlier repository match | Early hydrogen/storage portfolio |

## Editorial status

12 source-DOCX manuscripts were revised selectively (abstract, introduction, conclusion, selected passages); 1 wind draft was reconstructed from archived PDF; 3 new conceptual documents were developed. This does **not** amount to independent line-by-line rewriting, reference verification, coauthor approval, or numerical revalidation.
