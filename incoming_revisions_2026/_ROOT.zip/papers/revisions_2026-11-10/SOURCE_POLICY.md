# Source preservation, citation and research integrity

- `Source_Original.docx` or `.pdf` is provenance, not evidence that publication permission was obtained. Embedded published template imagery or third-party figures must be rights-checked before redistribution/republication.
- `Manuscript_Revised.*` retains original tables, figures and reference bodies where available. Preserve original file and revision date; never silently replace it with inferred data.
- `Source_Figures/` are extracted from source Word docs; their original licensing/credit requirements remain unchanged.
- `references_to_verify.bib` is an incomplete DOI-anchor staging file. No citation should be considered bibliographically verified solely because it appears there.
- If a paper lacks an original source, `SOURCE_AVAILABILITY.txt` records the package's provenance limitation. A related earlier version elsewhere in this repository does not retroactively convert a prospectus into completed experimental work.
- Keep measured-data, synthetic-data and conceptual results separately labeled. Never move results or figures across papers unless common sample definitions and generation scripts justify the comparison.
