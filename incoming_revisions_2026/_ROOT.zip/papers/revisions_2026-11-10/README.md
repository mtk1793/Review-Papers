# November 2026 Research Manuscript Revision Archive

This collection contains **16 distinct revision projects** and their source artifacts. It is separate from the older CAPSM/PRC Papers 1–13 elsewhere in `papers/`. The archive's P01–P16 identifiers **do not match** the older paper numbers.

**Readiness:** These are editorial revisions, reconstructed drafts and proposals. They are **not uniformly submission-ready**. Source-reported results were not rerun. Preserved source files may carry journal templates, embedded figures and historical publication text; preserve provenance and check copyright before redistribution.

**Canonical reading order:** `MANUSCRIPT_INDEX.csv` → each Pxx/README.md → `Manuscript_Revised.md`/`.docx` → `EDITORIAL_NOTES.md` → `REFERENCE_AUDIT.md` → `REPRODUCIBILITY_CHECKLIST.md`.

**Links with prior repository work:** `ALIGNMENT_AUDIT.md` explicitly documents similarities, non-equivalence and version boundaries. The older `papers/paper13_pgcare_ev_flexibility` remains the more developed PG-CARE reproducibility project; this archive does not overwrite or invalidate it.
