# PhD Publications | Manuscript revision archive

**Assembled:** 10 November 2026. **Total:** 16 paper folders (12 sourced DOCX rewrites, 1 reconstructed archived PDF article, 3 fresh methodological or prospective manuscripts).

## Read first

This is a multi-paper **editorial revision and research-development package**, not 16 peer-reviewed or submission-ready publications. For the 12 accessible `.docx` sources, the revision updates abstracts, the opening methodological argument, conclusions where identifiable, and targeted prose throughout. Source body sections, in-document figures, tables, equations, and references are otherwise preserved. It is therefore **not a full independent scientific rewrite of every paragraph**, nor evidence that all results are correct.

The wind article was rebuilt from its archival PDF as an editable manuscript. Three conceptual papers (P02, P14, P15) were composed without complete original manuscripts. They report no new empirical results and should not be described as completed experiments.

## Navigation

Each `Pxx_*` directory contains `Manuscript_Revised.docx`, `Manuscript_Revised.md`, `EDITORIAL_NOTES.md`, `REPRODUCIBILITY_CHECKLIST.md`, `REFERENCE_AUDIT.md`, `references_to_verify.bib`, and source originals when accessible. `Source_Figures` holds the original embedded figures extracted from Word files. `Source_Original.pdf` in P09 is the original historical conference paper. `MANUSCRIPT_INDEX.csv` gives a paper-by-paper inventory.

## Validation boundaries

1. No PSS/E, PSCAD, MATLAB or training job was executed as part of this revision package.
2. Existing percentages, errors, timing and performance scores are **source-reported**, not independently verified.
3. DOI-anchored BibTeX entries are placeholders for verification; they are not complete, publication-ready metadata.
4. NERC standard names, versions, adoption and enforceability require jurisdiction-specific official verification before submission.
5. Co-authorship, data-use rights, duplicate publication, and journal formatting require review.
6. Missing code, training data and unavailable original manuscripts are not silently substituted with fabricated results.

## Priority for credible submissions

PRC paper: finish province/standard/version matrix and reference check. MOD paper: perform measured-versus-simulated event testing and publish the executable pipeline. EV/solar/wind papers: reproduce all numbers with chronological splits and a baseline audit. FACTS/THD papers: connect prediction metrics to closed-loop physical benefits and safety checks. Hydrogen/storage articles: finish experiments and/or a systematic literature search before asserting numerical findings.
